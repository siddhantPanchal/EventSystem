package com.siddhant;

import com.siddUtil.delegates.IDelegate;

import java.util.Scanner;

public class GameManager {

    static Player player = new Player();
    static boolean exit = false;
    public static void main(String[] args) {
        player.onDie.subscribe(new IDelegate() {
            @Override
            public void run() {
                System.out.println("player died");
                exit = true;
            }
        });

        Scanner scanner = new Scanner(System.in);
        float damageRate;
        do {
            System.out.println("Enter damage : ");
            damageRate = scanner.nextFloat();
            player.damage(damageRate);
        }while (!exit);

    }

}