package com.siddhant;

import com.siddUtil.Event;

public class Player {

    Event onDie = new Event();
    float health = 100;

    void damage(float damageRate){
        health -= damageRate;
        System.out.println("player health : "+health);
        if(health <= 0){
            onDie.invoke(null);
        }
    }

}